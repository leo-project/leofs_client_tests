
/**
 * Marhsalling for the various types represented by AmazonAutoScaling.
 */
 package com.amazonaws.services.autoscaling.model.transform;
        